public class Character {

}
